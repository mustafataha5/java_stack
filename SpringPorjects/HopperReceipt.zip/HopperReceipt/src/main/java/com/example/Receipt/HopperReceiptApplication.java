package com.example.Receipt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HopperReceiptApplication {

	public static void main(String[] args) {
		SpringApplication.run(HopperReceiptApplication.class, args);
	}

}
